import scrapy

from jinjiang.items import JinjiangItem


class JbookSpider(scrapy.Spider):
    handle_httpstatus_list = [404]
    # 全局变量计算网页数量
    global i
    i = 3100000

    name = 'jbook'
    allowed_domains = ['jjwxc.net']
    start_urls = ['http://jjwxc.net/onebook.php?novelid=' + str(i)]

    # 自增以便爬取多个有规律页面
    def counti(self):
        global i
        i = i + 1


    def parse(self, response):
        # url自增
        self.counti()
        print(i)
        url_i = 'http://jjwxc.net/onebook.php?novelid=' + str(i)
        yield scrapy.Request(url_i, callback=self.parse,dont_filter=True)
        # 通过判断文章类型是否为空，处理302/404异常界面
        if response.xpath("//ul[@class='rightul' ] [@name='printright']/li[1]/span[2]/text()").extract_first() == None:
            item = JinjiangItem()
            item = None
            yield item
        else:
            # 通过目录中的start_time（第四第五行都没有）判断 处理没有目录的短篇题材
            if response.xpath("//tbody/tr[4]/td[6]/@title").extract_first() == None and response.xpath(
                    "//tbody/tr[5]/td[6]/@title").extract_first() == None:
                start_time = last_time = score = "null"
                name = response.xpath("//span[@class='bigtext']/text()").extract_first()
                author = response.xpath("//td[1]/a/text()").extract_first()
                type = response.xpath("//ul[@class='rightul' ] [@name='printright']/li[1]/span[2]/text()").extract_first()
                # 根据完结存在否，判断连载中和已完结状态判断
                if response.xpath(
                        "//ul[@class='rightul' ] [@name='printright']/li[5]/span[2]/font/text()").extract_first() == None:
                    state = response.xpath(
                        "//ul[@class='rightul' ] [@name='printright']/li[5]/span[2]/text()").extract_first()
                else:
                    state = response.xpath(
                        "//ul[@class='rightul' ] [@name='printright']/li[5]/span[2]/font/text()").extract_first()
                word = response.xpath("//ul[@class='rightul' ] [@name='printright']/li[6]/span[2]/text()").extract_first()
            # 正常页面有章节的书籍处理
            else:
                # 根据完结存在否，判断连载中和已完结状态判断
                if response.xpath(
                    "//ul[@class='rightul' ] [@name='printright']/li[5]/span[2]/font/text()").extract_first() == None:
                    state = response.xpath(
                    "//ul[@class='rightul' ] [@name='printright']/li[5]/span[2]/text()").extract_first()
                else:
                    state = response.xpath(
                        "//ul[@class='rightul' ] [@name='printright']/li[5]/span[2]/font/text()").extract_first()
                # 处理“最后更新时间”标签部分页面没有的问题
                if response.xpath("//span[@id='latestUpdates']/preceding-sibling::span").extract_first() == None:
                    h = len(response.xpath("//table[@id='oneboolt']/tbody/tr"))-2
                    print(h)
                    last = response.xpath(
                        "//table[@id='oneboolt']/tbody/tr")[h]
                    # 处理因为锁章或VIP章节导致的td[6]为空的问题，改为td[5]
                    if last.xpath("./td[6]/span/text()").extract_first() == None:
                        last_time = last.xpath("./td[5]/span/text()").extract_first()
                    else:
                        last_time = last.xpath("./td[6]/span/text()").extract_first()
                else:
                    last_time = response.xpath("//span[@id='latestUpdates']/preceding-sibling::span").extract_first()
                # 处理章节包含卷名引起的无法获取第一章发布时间问题
                if response.xpath("//tbody/tr[4]/td[6]/@title").extract_first() == None:

                    # 处理因为锁章导致的td[6]为空的问题，改为td[5]
                    if response.xpath("//tbody/tr[5]/td[6]/@title").extract_first() == None:
                        start_time = response.xpath("//tbody/tr[5]/td[5]/@title").extract_first()
                    else:
                        start_time = response.xpath("//tbody/tr[5]/td[6]/@title").extract_first()
                else:
                    # 处理因为锁章导致的td[6]为空的问题，改为td[5]
                    if response.xpath("//tbody/tr[4]/td[6]/@title").extract_first() == None:
                        start_time = response.xpath("//tbody/tr[4]/td[5]/@title").extract_first()
                    else:
                        start_time = response.xpath("//tbody/tr[4]/td[6]/@title").extract_first()
                type = response.xpath("//ul[@class='rightul' ] [@name='printright']/li[1]/span[2]/text()").extract_first()
                word = response.xpath("//ul[@class='rightul' ] [@name='printright']/li[6]/span[2]/text()").extract_first()
                name = response.xpath("//tbody/tr[1]/td[1]/div[1]/span[1]/h1/span/text()").extract_first()
                author = response.xpath("//tbody/tr[1]/td[1]/div[1]/h2/a/span/text()").extract_first()
                score = response.xpath("//td[@class='sptd'] [@colspan='6']")[1].xpath("./div/text()").extract()[4]



            # 处理字符段，去掉多余空格换行
            strlist = [type, state, word, name, author, start_time, last_time, score]
            # 处理name
            strlist[3] = strlist[3].strip().replace(' ', '_')
            # 处理类型，取最后一个字符
            strlist[0] = strlist[0].split('-')[-1].strip()
            # 处理author
            strlist[4] = strlist[4].strip().replace(' ', '_')
            # 处理start_time
            if strlist[5] == 'null':
                strlist[5] = '--'
            else:
                strlist[5] = strlist[5].split('章节')[1].split('：')[1].split(' ')[0]
            # 处理last_time
            if strlist[6] == 'null':
                strlist[6] = '--'
            else:
                strlist[6] = strlist[6].split()[1]
            # 处理文章积分
            if strlist[7] == 'null':
                strlist[7] = '0'
            else:
                strlist[7] = strlist[7].split('：')[1].replace(',', '').strip()
            # 处理state
            strlist[1] = strlist[1].strip().replace(' ', '_')
            # 处理Word
            strlist[2] = strlist[2].strip().replace(' ', '_')


            item = JinjiangItem()
            item["type"] = strlist[0]
            item["state"] = strlist[1]
            item["word"] = strlist[2]
            item["name"] = strlist[3]
            item["author"] = strlist[4]
            item["start_time"] = strlist[5]
            item["last_time"] = strlist[6]
            item["score"] = strlist[7]

            yield item
            print(item["name"] + " " + item["type"] + " " + item["author"] + " " + item["score"] + " " +
                  item["word"] + " " + item["start_time"] + " " + item["last_time"] + " " +
                  item["state"] + "\n")
            # print(item["type"])
            # print(item["state"])
            # print(item["word"])
            # print(item["name"])
            # print(item["author"])
            # print(item["start_time"])
            # print(item["last_time"])
