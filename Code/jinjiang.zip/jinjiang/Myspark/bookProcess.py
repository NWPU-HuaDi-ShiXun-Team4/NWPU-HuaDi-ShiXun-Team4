from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
sc = spark.sparkContext
# print(sc.version)
# file = r"C:\nwpu\pythonbasic\ceshispark.txt"
# # 读取文件 用foreach输出
# textFile = sc.textFile(file)
# textFile.foreach(print)

# # map的用法
# tem_list = list(range(10))
# rdd1 = sc.parallelize(tem_list)
# rdd2 = rdd1.map(lambda x: x + x)
# data  = rdd2.collect()
# [print(item) for item in data]

# file = r"C:\nwpu\pythonbasic\ceshispark.txt"
# rdd1 = sc.textFile(file)
# data = rdd1.flatMap(lambda x: x.split(" "))
# data.foreach(print)

# 1 预处理文本 去重
# file = r"C:\nwpu\pythonbasic\ceshispark.txt"
# rdd1 = sc.textFile(file).distinct().collect()
# [print(item) for item in rdd1]

# 2 题材收录排行
# file = r"C:\nwpu\pythonbasic\book.txt"
# rdd1 = sc.textFile(file).distinct()
# rdd2 = rdd1.filter(lambda x: len(x.split(" ")) == 8).filter(lambda x: "  " not in x).filter(lambda x: "　" not in x).\
#     filter(lambda x: "\t" not in x)
# rdd3 = rdd2.map(lambda x: x.split(" ")[1]).map(lambda style: (style, 1))
# data = rdd3.reduceByKey(lambda x, y: x+y).sortBy(lambda x: x[1], False).collect()
# dataSum = 0
# list1 = []
# for item in data:
#     item = list(item)
#     dataSum += int(item[1])
# # print(dataSum)
# for item in data:
#     item = list(item)
#     item.append('%.6f' % (int(item[1])/dataSum))
#     list1.append(item)
#     # print(item)
# # [print(item) for item in data]
# # [print(item) for item in data]
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\bookType_result.txt", "w", encoding='utf-8')
# for item in list1:
#     f1.write(item[0] + " " + str(item[1]) + " " + str(item[2]))
#     f1.write("\n")
# f1.close()

# # 3 作者积分排行
# file = r"C:\nwpu\pythonbasic\book.txt"
# rdd1 = sc.textFile(file).distinct()
# rdd2 = rdd1.filter(lambda x: len(x.split(" ")) == 8)
# rdd3 = rdd2.map(lambda x: x.split(" ")[2:4])
# rdd4 = rdd3.reduceByKey(lambda x, y: int(x) + int(y)).sortBy(lambda x: int(x[1]), False)
# data = list(rdd4.take(num=10))
# # [print(item) for item in data]
# # print(type(data))
# # print(data[1])
# rdd5 = rdd2.map(lambda x: ('-'.join(x.split()[0:2]), x.split()[2])).sortBy(lambda y: y[1], False)
# zuoPin = list(rdd5.collect())
# list1 = []
# for item in data:
#     item = list(item)
#     for m in zuoPin:
#         if m[1] == item[0]:
#             item.append(m[0])
#     list1.append(item)
# # [print(item[2]) for item in list1]
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\authorCredit_result.txt", "w", encoding='utf-8')
# for item in list1:
#     f1.write(item[0] + " " + str(item[1]) + " " + item[2] + " " +
#              item[3] + " " + item[4] + " " + item[5] + " " + item[6])
#     f1.write("\n")
# f1.close()

# 4 用户稳定性分析
# file = r"C:\nwpu\pythonbasic\month.txt"
# rdd1 = sc.textFile(file)
# dataSum = rdd1.map(lambda x: int(x.split(" ")[4])).sum()
# rdd4 = rdd1.map(lambda x: x.split(" ")[3:5])
# data = rdd4.reduceByKey(lambda x, y: int(x)+int(y)).collect()
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\month_result.txt", "w", encoding='utf-8')
# for item in data:
#     result = int(item[1])/dataSum
#     f1.write(item[0] + " " + str('%.4f' % result))
#     f1.write("\n")
# f1.close()
#
# file = r"C:\nwpu\pythonbasic\quarter.txt"
# rdd1 = sc.textFile(file)
# dataSum = rdd1.map(lambda x: int(x.split(" ")[4])).sum()
# rdd4 = rdd1.map(lambda x: x.split(" ")[3:5])
# data = rdd4.reduceByKey(lambda x, y: int(x)+int(y)).collect()
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\quarter_result.txt", "w", encoding='utf-8')
# for item in data:
#     result = int(item[1])/dataSum
#     f1.write(item[0] + " " + str('%.4f' % result))
#     f1.write("\n")
# f1.close()
#
# file = r"C:\nwpu\pythonbasic\year.txt"
# rdd1 = sc.textFile(file)
# dataSum = rdd1.map(lambda x: int(x.split(" ")[4])).sum()
# rdd4 = rdd1.map(lambda x: x.split(" ")[3:5])
# data = rdd4.reduceByKey(lambda x, y: int(x)+int(y)).collect()
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\year.txt", "w", encoding='utf-8')
# for item in data:
#     result = int(item[1])/dataSum
#     f1.write(item[0] + " " + str('%.4f' % result))
#     f1.write("\n")
# f1.close()

# 5 读者订阅偏好
# file = r"C:\nwpu\pythonbasic\reader_prefer.txt"
# rdd1 = sc.textFile(file)
# # 计算每个读者近期所阅读的所有书籍总数
# typeSum = rdd1.map(lambda x: x.split()[1:3]).countByKey()
# # print(typeSum)
# # print(typeSum.get("123"))
# # 将前三列提取出来合并为str作为Key，再计算每个读者每种题材书籍的阅读数目
# rdd3 = rdd1.map(lambda x: ((' '.join(x.split(" ")[0:3])), 1))
# rdd4 = rdd3.reduceByKey(lambda x, y: x+y).sortByKey()
# data = rdd4.collect()
# list2 = []
# for item in data:
#     list1 = item[0].split()
#     # 计算每个读者每种题材阅读占比
#     list1.append('%.4f' % (item[1]/(typeSum.get(list1[1]))))
#     # tmp = ' '.join(list1)
#     list2.append(list1)
# list2.sort(key=lambda elem: int(elem[0]), reverse=False)
# # for item in list2:
# #     result = ' '.join(item)
# #     print(result)
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\reader_prefer_result.txt", "w", encoding='utf-8')
# for item in list2:
#     result = ' '.join(item)
#     f1.write(result + "\n")
# f1.close()

# 各题材top10
# file = r"C:\nwpu\pythonbasic\book.txt"
# rdd1 = sc.textFile(file).distinct()
# rdd2 = rdd1.filter(lambda x: "  " not in x).filter(lambda x: "　" not in x).filter(lambda x: "\t" not in x).\
#     filter(lambda x: len(x.split()) == 8)
# rdd3 = rdd2.map(lambda x: x.split()[0:4])
# rdd4 = rdd3.sortBy(lambda x: (x[1], int(x[3])), False)
# data = rdd4.collect()
# rdd5 = rdd2.map(lambda x: x.split(" ")[1]).map(lambda style: (style, 1)).reduceByKey(lambda x, y: x+y)
# bookType = rdd5.sortBy(lambda x: x[0]).collect()
# # [print(item) for item in bookType]
# list2 = []
# mySlice = slice(10)
# for item in bookType:
#     list1 = []
#     for m in data:
#         if m[1] == item[0]:
#             list1.append(m)
#     # list2.append(list1[:10])
#     if len(list1) < 10:
#         for i in list1:
#             list2.append(i)
#     else:
#         for i in list1[:10]:
#             list2.append(i)
# # [print(item) for item in list2]
# f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\bookTypeTOP10.txt", "w", encoding='utf-8')
# for item in list2:
#     f1.write(item[0] + " " + item[1] + "  " + item[2] + " " + str(item[3]))
#     f1.write("\n")
# f1.close()

# 书籍积分排行
file = r"C:\nwpu\pythonbasic\score.txt"
rdd1 = sc.textFile(file).distinct()
rdd3 = rdd1.map(lambda x: x.split()[1:5])
rdd4 = rdd3.sortBy(lambda x: int(x[3]), False)
data = rdd4.collect()
f1 = open(r"C:\nwpu\pythonbasic\result_JinJiangBangDan\score_result.txt", "w", encoding='utf-8')
for item in data:
    f1.write(item[0] + " " + item[1] + "  " + item[2] + " " + str(item[3]))
    f1.write("\n")
f1.close()
# [print(item) for item in data]

