# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class JinjiangItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    # 排名
    rank = scrapy.Field()
    # 作者名字
    author = scrapy.Field()
    # 书名
    name = scrapy.Field()
    # 书的类型
    type = scrapy.Field()
    # 书的完结状态
    state = scrapy.Field()
    # 书的字数
    word = scrapy.Field()
    # 书的积分
    score = scrapy.Field()
    # 书的起始更新时间
    start_time = scrapy.Field()
    # 书的最后更新时间
    last_time = scrapy.Field()
    # 读者名字
    reader_name = scrapy.Field()
    # 书的霸王票（但没爬到数据）
    ticket_book = scrapy.Field()
    # 读者投的总霸王票数
    ticket_reader = scrapy.Field()
    # 读者最近收藏（应该是个list，现在只爬到了一个）
    reader_book_star = scrapy.Field()
    # 读者最近订阅（应该是个list，现在只爬到了一个）
    reader_book_view = scrapy.Field()
