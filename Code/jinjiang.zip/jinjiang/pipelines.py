# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


class JinjiangPipeline:
    def process_item(self, item, spider):
        with open("book_309.txt", "a+", encoding = 'utf-8') as f:
            f.write(item["name"] + " " + item["type"] + " " + item["author"] + " " + item["score"] + " " +
                  item["word"] + " " + item["start_time"] + " " + item["last_time"] + " " +
                  item["state"] + "\n")
