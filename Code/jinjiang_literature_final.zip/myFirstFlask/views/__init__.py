import pymysql
# 解决python3.x与mysql驱动不兼容的问题

pymysql.install_as_MySQLdb()