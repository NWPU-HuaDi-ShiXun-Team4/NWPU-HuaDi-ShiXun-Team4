import json

from flask import Blueprint, render_template
from config import db
from dbmodels.AuthorCredits import AuthorCredits
from dbmodels.BookTypeResult import BookTypeResult
from dbmodels.BookTypeTop10 import BookTypeTop10
from dbmodels.LongNovelRate import LongNovelRate
from dbmodels.MonthRate import MonthRate
from dbmodels.MonthResult import MonthResult
from dbmodels.NewAuthor import NewAuthor
from dbmodels.QuarterRate import QuarterRate
from dbmodels.QuarterResult import QuarterResult
from dbmodels.Reader import Reader
from dbmodels.ReaderPrefer import ReaderPrefer
from dbmodels.ScoreRate import ScoreRate
from dbmodels.TicketRate import TicketRate
from dbmodels.YearRate import YearRate
from dbmodels.YearResult import YearResult

data = Blueprint("data", __name__)

'''@data.route("/get_booktype_result")
def get_booktype_result():
    data1 = db.session.query(BookTypeResult).all()
    view_data1 = {}
    # view_data["series"] = []
    list_type1 = []
    list_num1 = []
    list_proportion1 = []

    def build_view_data(item):
        list_type1.append(item.type)
        list_num1.append(item.num)
        list_proportion1.append(item.proportion)

    [build_view_data(i) for i in data1]
    view_data1['type'] = list_type1
    view_data1['num'] = list_num1
    view_data1['proportion'] = list_proportion1
    print(json.dumps(view_data1))
    return json.dumps(view_data1, ensure_ascii=False)
'''

'''  type = ['python', 'java', 'c', 'c++', 'c#', 'php']
    proportion = ['100', '150', '100', '90', '80', '90']
    return json.dumps({'type': type, 'proportion': proportion}, ensure_ascii=False)
'''


# 各题材占比
@data.route("/get_booktype_result")
def get_booktype_result():
    data1 = db.session.query(BookTypeResult).all()
    view_data1 = {}
    view_data1["series"] = []

    def build_view_data1(item):
        dic1 = {}
        dic1["name"] = item.type
        dic1["value"] = item.num
        dic1["proportion"] = item.proportion
        view_data1["series"].append(dic1)
        print(dic1)

    [build_view_data1(i) for i in data1]
    return json.dumps(view_data1)


@data.route("/get_month_rate")
def get_month_rate():
    data2 = db.session.query(MonthRate).all()
    view_data2 = {}
    view_data2["series"] = []

    def build_view_data(item):
        dic2 = {}
        dic2["name"] = item.name
        dic2["value"] = item.score
        dic2["rank"] = item.rank
        dic2["author"] = item.author
        dic2["type"] = item.type

        view_data2["series"].append(dic2)
        print(dic2)

    [build_view_data(i) for i in data2]
    return json.dumps(view_data2)


@data.route("/get_quarter_rate")
def get_quarter_rate():
    data3 = db.session.query(QuarterRate).all()
    view_data3 = {}
    view_data3["series"] = []

    def build_view_data(item):
        dic3 = {}
        dic3["name"] = item.name
        dic3["value"] = item.score
        dic3["rank"] = item.rank
        dic3["author"] = item.author
        dic3["type"] = item.type

        view_data3["series"].append(dic3)
        print(dic3)

    [build_view_data(i) for i in data3]
    return json.dumps(view_data3)


@data.route("/get_year_rate")
def get_year_rate():
    data4 = db.session.query(YearRate).all()
    view_data4 = {}
    view_data4["series"] = []

    def build_view_data(item):
        dic4 = {}
        dic4["name"] = item.name
        dic4["value"] = item.score
        dic4["rank"] = item.rank
        dic4["author"] = item.author
        dic4["type"] = item.type

        view_data4["series"].append(dic4)
        print(dic4)

    [build_view_data(i) for i in data4]
    return json.dumps(view_data4)


# 用户稳定性分析
'''@data.route("/get_reader_stability")
def get_reader_stability():
    data1 = db.session.query(MonthResult).all()
    data2 = db.session.query(QuarterRate).all()
    data3 = db.session.query(YearResult).all()
    view_data = {}

    view_data["data1"] = []
    view_data["data2"] = []
    view_data["data3"] = []

    def build_view_data1(item):
        dic = {}
        dic["name"] = item.type
        dic["value"] = item.proportion
        dic["id"] = item.id

        view_data["data1"].append(dic)
        print(dic)

    [build_view_data1(i) for i in data1]

    def build_view_data2(item):
        dic = {}
        dic["name"] = item.type
        dic["value"] = item.proportion
        dic["id"] = item.id

        view_data["data2"].append(dic)
        print(dic)

    [build_view_data2(i) for i in data2]

    def build_view_data3(item):
        dic = {}
        dic["name"] = item.type
        dic["value"] = item.proportion
        dic["id"] = item.id

        view_data["data3"].append(dic)
        print(dic)

    [build_view_data3(i) for i in data3]

    return json.dumps(view_data)
'''


@data.route("/get_reader_stability")
def get_reader_stability():
    data1 = db.session.query(MonthResult).all()
    data2 = db.session.query(QuarterResult).all()
    data3 = db.session.query(YearResult).all()
    view_data = {}
    list_romance = []
    list_qihuan = []
    list_juqing = []
    list_xianxia = []
    list_qingxiaoshuo = []
    list_xuanyi = []
    list_qita = []
    list_dongfang = []
    list_kehuan = []
    list_youxi = []
    list_xifang = []
    list_chuanqi = []
    list_gudian = []
    list_tonghua = []
    list_wuxia = []
    list_jingsong = []

    def build_view_data(item):
        if item.type == "爱情":
            list_romance.append(item.proportion)
        elif item.type == "奇幻":
            list_qihuan.append(item.proportion)
        elif item.type == "剧情":
            list_juqing.append(item.proportion)
        elif item.type == "仙侠":
            list_xianxia.append(item.proportion)
        elif item.type == "轻小说":
            list_qingxiaoshuo.append(item.proportion)
        elif item.type == "悬疑":
            list_xuanyi.append(item.proportion)
        elif item.type == "其他衍生":
            list_qita.append(item.proportion)
        elif item.type == "东方衍生":
            list_dongfang.append(item.proportion)
        elif item.type == "科幻":
            list_kehuan.append(item.proportion)
        elif item.type == "游戏":
            list_youxi.append(item.proportion)
        elif item.type == "西方衍生":
            list_xifang.append(item.proportion)
        elif item.type == "传奇":
            list_chuanqi.append(item.proportion)
        elif item.type == "古典衍生":
            list_gudian.append(item.proportion)
        elif item.type == "童话":
            list_tonghua.append(item.proportion)
        elif item.type == "武侠":
            list_wuxia.append(item.proportion)
        elif item.type == "惊悚":
            list_jingsong.append(item.proportion)

    [build_view_data(i) for i in data1]
    [build_view_data(i) for i in data2]
    [build_view_data(i) for i in data3]
    view_data['爱情'] = list_romance
    view_data['奇幻'] = list_qihuan
    view_data['剧情'] = list_juqing
    view_data['仙侠'] = list_xianxia
    view_data['轻小说'] = list_qingxiaoshuo
    view_data['悬疑'] = list_xuanyi
    view_data['其他衍生'] = list_qita
    view_data['东方衍生'] = list_dongfang
    view_data['科幻'] = list_kehuan
    view_data['游戏'] = list_youxi
    view_data['西方衍生'] = list_xifang
    view_data['传奇'] = list_chuanqi
    view_data['古典衍生'] = list_gudian
    view_data['童话'] = list_tonghua
    view_data['武侠'] = list_wuxia
    view_data['惊悚'] = list_jingsong

    return json.dumps(view_data)


# 长篇排行
@data.route("/get_novel_rate")
def get_novel_rate():
    data = db.session.query(LongNovelRate).all()
    view_data = {}
    view_data["series"] = []

    def build_view_data(item):
        dic = {}
        dic["name"] = item.name
        dic["value"] = item.score
        dic["rank"] = item.rank
        dic["author"] = item.author
        dic["type"] = item.type

        view_data["series"].append(dic)
        print(dic)

    [build_view_data(i) for i in data]
    return json.dumps(view_data)


# 积分排行
@data.route("/get_score_rate")
def get_score_rate():
    data = db.session.query(ScoreRate).all()
    view_data = {}
    view_data["series"] = []

    def build_view_data(item):
        dic = {}
        dic["name"] = item.name
        dic["value"] = item.score
        dic["id"] = item.id
        dic["author"] = item.author
        dic["type"] = item.type

        view_data["series"].append(dic)
        print(dic)

    [build_view_data(i) for i in data]
    return json.dumps(view_data)


# 打赏收益排行
@data.route("/get_ticket_rate")
def get_ticket_rate():
    data = db.session.query(TicketRate).all()
    view_data = {}
    view_data["series"] = []

    def build_view_data(item):
        dic = {}
        dic["name"] = item.name
        dic["value"] = item.score
        dic["rank"] = item.rank
        dic["author"] = item.author
        dic["type"] = item.type

        view_data["series"].append(dic)
        print(dic)

    [build_view_data(i) for i in data]
    return json.dumps(view_data)


# 新晋作者排行
@data.route("/get_new_author")
def get_new_author():
    data = db.session.query(NewAuthor).all()
    view_data = {}
    view_data["series"] = []

    def build_view_data(item):
        dic = {}
        dic["name"] = item.name
        dic["value"] = item.score
        dic["rank"] = item.rank
        dic["author"] = item.author
        dic["type"] = item.type

        view_data["series"].append(dic)
        print(dic)

    [build_view_data(i) for i in data]
    return json.dumps(view_data)


# 作者积分排行
@data.route("/get_author_credit")
def get_author_credit():
    data = db.session.query(AuthorCredits).all()
    view_data = {}
    view_data["series"] = []

    def build_view_data(item):
        dic = {}
        dic["id"] = item.id
        dic["name"] = item.author
        dic["value"] = item.credit
        dic["book1"] = item.book1
        dic["book2"] = item.book2
        dic["book3"] = item.book3
        dic["book4"] = item.book4
        dic["book5"] = item.book5

        view_data["series"].append(dic)
        print(dic)

    [build_view_data(i) for i in data]
    return json.dumps(view_data)


# 读者消费排行
@data.route("/get_reader_rate")
def get_reader_rate():
    data1 = db.session.query(Reader).all()
    data2 = db.session.query(ReaderPrefer).all()
    view_data = {}
    view_data["series"] = []

    def build_view_data1(item):
        dic = {}
        dic["rank"] = item.rank
        dic["name"] = item.reader_name
        dic["value"] = item.ticket_reader
        dic['prefer'] = []
        view_data["series"].append(dic)
        print(dic)

    [build_view_data1(i) for i in data1]
    print(view_data)

    def build_view_data2(item):
        dic1 = {}
        dic1["rank"] = item.rank
        dic1["name"] = item.type
        dic1["value"] = item.rate
        if dic1['rank'] == 1:
            view_data['series'][0]['prefer'].append(dic1)
        elif dic1['rank'] == 2:
            view_data['series'][1]['prefer'].append(dic1)
        elif dic1['rank'] == 3:
            view_data['series'][2]['prefer'].append(dic1)
        elif dic1['rank'] == 4:
            view_data['series'][3]['prefer'].append(dic1)
        elif dic1['rank'] == 5:
            view_data['series'][4]['prefer'].append(dic1)
        elif dic1['rank'] == 6:
            view_data['series'][5]['prefer'].append(dic1)
        elif dic1['rank'] == 7:
            view_data['series'][6]['prefer'].append(dic1)
        elif dic1['rank'] == 8:
            view_data['series'][7]['prefer'].append(dic1)
        elif dic1['rank'] == 9:
            view_data['series'][8]['prefer'].append(dic1)
        elif dic1['rank'] == 10:
            view_data['series'][9]['prefer'].append(dic1)

    [build_view_data2(i) for i in data2]
    print(view_data)
    return json.dumps(view_data)


# 各题材top10
@data.route("/get_booktype_top10")
def get_booktype_top10():
    data = db.session.query(BookTypeTop10).all()
    view_data = {}

    list_romance = []
    list_qihuan = []
    list_juqing = []
    list_xianxia = []
    list_qingxiaoshuo = []
    list_xuanyi = []
    list_qita = []
    list_dongfang = []
    list_kehuan = []
    list_youxi = []
    list_xifang = []
    list_chuanqi = []
    list_gudian = []
    list_tonghua = []
    list_wuxia = []
    list_jingsong = []
    list_pinglun = []
    list_sanwen = []
    list_shige = []
    list_suibi = []
    list_yuyan = []
    list_weizhi = []

    def build_view_data(item):
        dic = {}
        dic['name'] = item.book
        dic['value'] = item.credit
        dic['type'] = item.type
        dic['rank'] = item.rank

        if dic['type'] == "爱情":
            list_romance.append(dic)
        elif dic['type'] == "奇幻":
            list_qihuan.append(dic)
        elif dic['type'] == "剧情":
            list_juqing.append(dic)
        elif dic['type'] == "仙侠":
            list_xianxia.append(dic)
        elif dic['type'] == "轻小说":
            list_qingxiaoshuo.append(dic)
        elif dic['type'] == "悬疑":
            list_xuanyi.append(dic)
        elif dic['type'] == "其他衍生":
            list_qita.append(dic)
        elif dic['type'] == "东方衍生":
            list_dongfang.append(dic)
        elif dic['type'] == "科幻":
            list_kehuan.append(dic)
        elif dic['type'] == "游戏":
            list_youxi.append(dic)
        elif dic['type'] == "西方衍生":
            list_xifang.append(dic)
        elif dic['type'] == "传奇":
            list_chuanqi.append(dic)
        elif dic['type'] == "古典衍生":
            list_gudian.append(dic)
        elif dic['type'] == "童话":
            list_tonghua.append(dic)
        elif dic['type'] == "武侠":
            list_wuxia.append(dic)
        elif dic['type'] == "惊悚":
            list_jingsong.append(dic)
        elif dic['type'] == "评论":
            list_pinglun.append(dic)
        elif dic['type'] == "散文":
            list_sanwen.append(dic)
        elif dic['type'] == "诗歌":
            list_shige.append(dic)
        elif dic['type'] == "随笔":
            list_suibi.append(dic)
        elif dic['type'] == "寓言":
            list_yuyan.append(dic)
        elif dic['type'] == "未知":
            list_weizhi.append(dic)

    [build_view_data(i) for i in data]

    view_data['东方衍生'] = list_dongfang
    view_data['仙侠'] = list_xianxia
    view_data['传奇'] = list_chuanqi
    view_data['其他衍生'] = list_qita
    view_data['剧情'] = list_juqing
    view_data['古典衍生'] = list_gudian
    view_data['奇幻'] = list_qihuan
    view_data['寓言'] = list_yuyan
    view_data['悬疑'] = list_xuanyi
    view_data['惊悚'] = list_jingsong
    view_data['散文'] = list_sanwen
    view_data['未知'] = list_weizhi
    view_data['武侠'] = list_wuxia
    view_data['游戏'] = list_youxi
    view_data['爱情'] = list_romance
    view_data['科幻'] = list_kehuan
    view_data['童话'] = list_tonghua
    view_data['西方衍生'] = list_xifang
    view_data['评论'] = list_pinglun
    view_data['诗歌'] = list_shige
    view_data['轻小说'] = list_qingxiaoshuo
    view_data['随笔'] = list_suibi

    print(view_data)
    return json.dumps(view_data)
