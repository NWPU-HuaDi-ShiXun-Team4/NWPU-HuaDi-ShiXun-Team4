var EndEarningsChart = echarts.init(document.getElementById('EndEarningsChart'));

var data = [
    [[148344368,10,20000000,'《嫁君欢》'],
     [166857440,17,30000000,'《我在修仙界发展美食》'],
     [174702624,55,40000000,'《无限险境》'],
     [218592224,75,60000000,'《恕我直言》'],
     [252660784,25,80000000,'《娇藏》'],
     [259253152,87,100000000,'《位面火锅店》'],
     [283787040,35,120000000,'《科技女王[快穿]》'],
     [353242976,65,140000000,'《技术派侧福晋》'],
     [357109216,47,160000000,'《石榴小皇后》'],
     [389223680,100,170000000,'《神也别想拦着我搞基建！》'],
     [584987648,80,190000000,'《大唐长公主》'],
     [739345152,91,210000000,'《人面鲵》'],
     [767113088,15,320000000,'《发光体》'],
     [827354816,30,330000000,'《大清皇孙日常》'],
     [998166784,110,340000000,'《原著杀我》'],
     [1258660096,55,350000000,'《慈悲殿》'],
     [1326204032,75,360000000,'《穿成绿茶女配后我出道了》'],
     [1532884864,20,370000000,'《爱豆家里有道观》'],
     [1787618432,87,380000000,'《北斗》'],
     [1837673216,40,450000000,'《偏执男主白月光我不当了》'],
     [2120389632,5,470000000,'《月明千里》'],
     [2321430016,100,490000000,'《诈欺大师》'],
     [2427629312,70,510000000,'《末日领主》'],
     [3038418432,35,540000000,'《菩珠》'],
     [3155354112,85,650000000,'《夫君是未来大魔王怎么办？》'],
     [3667299840,50,760000000,'《豪门父母和顶流哥哥终于找到了我》'],
     [3745165312,5,860000000,'《海王翻车了》'],
     [4654447104,100,1280000000,'《错撩》'],
     [4644294656,70,1290000000,'《深情男配今天崩了吗》'],
     [5059724288,25,2300000000,'《骷髅幻戏图》']]
    ];
   EndEarningsChart.setOption({

//     backgroundColor: new echarts.graphic.RadialGradient(0.3, 0.3, 0.8, [{
//        offset: 0,
//        color: '#f7f8fa'
//    }, {
//        offset: 1,
//        color: '#cdd0d5'
//    }]),

     grid:{
         x:'3%',
         y:'10%',
         x2:'15%',
         bottom:'1%',
         containLabel: true
     },
     tooltip : {
        trigger: 'item',
        showContent:false
     },
     calculable : true,
     xAxis : [
         {
            splitLine: {
                lineStyle: {
                    type: 'dashed',
                    color: '#081832'
                    },
                },
            axisLine:{
                  lineStyle:{
                      type: 'dashed',
                      color: '#081832'
                  },
                  show: false
              },

			axisTick: {
					show: false
				}
         }
     ],
     yAxis : [
         {
            splitLine: {
                lineStyle: {
                    type: 'dashed',
                    color: '#081832'
                    },
                },
            axisLine:{
                  lineStyle:{
                      type: 'dashed',
                      color: '#081832'
                  },
              },
             axisTick: {
					show: false
			},
            scale: true
         }
     ],
     series: [
         {
             data: data[0],
             type: 'scatter',
             symbolSize: function (data) {
                return Math.sqrt(data[2]) / 5e2;
                },
             emphasis: {
                label: {
                    show: true,
                    formatter: function (param) {
                        return param.data[3];
                    },
                    position: 'inside',
                    color: '#FFFFFF'
                }
             },
             itemStyle: {
                shadowBlur: 10,
                shadowColor: 'rgba(25, 100, 150, 0.5)',
                shadowOffsetY: 5,
                color: new echarts.graphic.RadialGradient(0.4, 0.3, 1, [{
                    offset: 0,
                    color: 'rgb(129, 227, 238)'
                    }, {
                        offset: 1,
                        color: 'rgb(25, 183, 207)'
                        }])
                }
         },
    ]
   })