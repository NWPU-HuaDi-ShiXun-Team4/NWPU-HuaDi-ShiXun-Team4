var WebRankChart = echarts.init(document.getElementById("WebRankChart"))
var myColor = ['#1089E7', '#F57474', '#56D0E3', '#F8B448', '#8B78F6']


WebRankChart.setOption({

     color:['#5bc0de'],
     grid:{
         x:'2%',
         y:'20%',
         x2:'15%',
         bottom:'7%',
         containLabel: true
     },
     tooltip : {
        trigger: 'axis'
     },
     legend: {
        data: ['晋江', '起点', '纵横', '顶点', '潇湘'],
        padding:[30,30,0,0],   //可设定图例[距上方距离，距右方距离，距下方距离，距左方距离]
        textStyle:{
                    color: '#FD6C88'
           }
     },
     calculable : true,
     toolbox: {
        feature: {
            saveAsImage: {}
        }
    },
     xAxis : [
         {
            type: 'category',
            boundaryGap: false,
            axisLine:{
//                  interval：auto,//横轴信息全部显示
//                  rotate: 45,//60度角倾斜显示


                  lineStyle:{
                      color: '#5bc0de'
                  }
            },
            data: ['预估流量', '索引量', 'Alexa排名', '百度反链数', '谷歌反链数', '360反链数']
         }
     ],
     yAxis : [
         {
             type : 'value',
             axisLine:{
                 lineStyle:{
                     color: '#5bc0de'
                 }
             },
             splitLine: {
                 "show": false
             },
             axisLabel: {
                 textStyle: {
                     color: '#fff'
                 },
                 formatter: '{value} 万'
             },
         }
     ],
     series : [
         {
            name: '晋江',
            type: 'line',
            itemStyle: {color:'#1089E7'},
            data: [29.04, 3811.24, 0.1593, 8.26, 8.69, 2470]
        },
        {
            name: '起点',
            type: 'line',
            itemStyle: {color:'#F57474'},
            data: [40.88, 3784.78, 0.3077, 1.71, 9.02, 774]
        },
        {
            name: '纵横',
            type: 'line',
            itemStyle: {color:'#56D0E3'},
            data: [14.59, 803.29, 24.8, 885, 650, 0.0153]
        },
        {
            name: '顶点',
            type: 'line',
            itemStyle: {color:'#F8B448'},
            data: [7.58, 66.82, 0, 5.84, 1.03, 276]
        },
        {
            name: '潇湘',
            type: 'line',
            itemStyle: {color:'#8B78F6'},
            data: [2.11, 1134.62, 1.72, 0.5370, 3.49, 821]
        }
     ]
   })
//var option_web = {
//
//     color:['#5bc0de'],
//     grid:{
//         left: '5%',
//         right: '5%',
//         bottom: '5%',
//         containLabel: true
//     },
//     tooltip : {
//        trigger: 'axis'
//     },
//     legend: {
//        data: ['晋江', '起点', '纵横', '顶点', '潇湘'],
//        textStyle:{
//                    color: '#FD6C88',
//           }
//     },
//     calculable : true,
//     toolbox: {
//        feature: {
//            saveAsImage: {}
//        }
//    },
//     xAxis : {
//            type: 'category',
//            boundaryGap: false,
//            axisLine:{
//                  lineStyle:{
//                      color: '#5bc0de',
//                  }
//            },
//            data: ['预估流量', '索引量', 'Alexa排名', '百度反链数', '谷歌反链数', '360反链数']
//         }
//
//     yAxis : {
//             type : 'value',
//             axisLine:{
//                 lineStyle:{
//                     color: '#5bc0de',
//                 }
//             },
//             splitLine: {
//                 "show": false,
//             },
//             axisLabel: {
//                 textStyle: {
//                     color: '#fff',
//                 },
//                 formatter: '{value} 万'
//             }
//         },
//
//     series : [
//         {
//            name: '晋江',
//            type: 'line',
//            itemStyle: {color:'#1089E7'},
//            data: [29.04, 3811.24, 0.1593, 8.26, 8.69, 2470]
//        },
//        {
//            name: '起点',
//            type: 'line',
//            itemStyle: {color:'#F57474'},
//            data: [40.88, 3784.78, 0.3077, 1.71, 9.02, 774]
//        },
//        {
//            name: '纵横',
//            type: 'line',
//            itemStyle: {color:'#56D0E3'},
//            data: [14.59, 803.29, 24.8, 885, 650, 0.0153]
//        },
//        {
//            name: '顶点',
//            type: 'line',
//            itemStyle: {color:'#F8B448'},
//            data: [7.58, 66.82, 0, 5.84, 1.03, 276]
//        },
//        {
//            name: '潇湘',
//            type: 'line',
//            itemStyle: {color:'#8B78F6'},
//            data: [2.11, 1134.62, 1.72, 0.5370, 3.49, 821]
//        }
//     ]
//};
//    WebRankChart.setOption(option_web)
//
//
