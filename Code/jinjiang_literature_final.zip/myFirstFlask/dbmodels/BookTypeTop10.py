from config import db


class BookTypeTop10(db.Model):
    __tablename__ = "booktype_top10"
    id = db.Column(db.INT, primary_key=True)
    rank = db.Column(db.INT)
    book = db.Column(db.String(20))
    type = db.Column(db.String(20))
    author = db.Column(db.String(20))
    credit = db.Column(db.INT)

