from config import db


class YearResult(db.Model):
    __tablename__ = "year_result"
    id = db.Column(db.INT, primary_key=True)
    type = db.Column(db.String(20))
    proportion = db.Column(db.Float(40))