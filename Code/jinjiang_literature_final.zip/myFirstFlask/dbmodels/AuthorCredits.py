from config import db


class AuthorCredits(db.Model):
    __tablename__ = "author_credit"
    id = db.Column(db.INT, primary_key=True)
    author = db.Column(db.String(20))
    credit = db.Column(db.INT)
    book1 = db.Column(db.String(20))
    book2 = db.Column(db.String(20))
    book3 = db.Column(db.String(20))
    book4 = db.Column(db.String(20))
    book5 = db.Column(db.String(20))
