from config import db


class ScoreRate(db.Model):
    __tablename__ = "score_rate"
    id = db.Column(db.INT, primary_key=True)
    author = db.Column(db.String(20))
    name = db.Column(db.String(20))
    type = db.Column(db.String(20))
    score = db.Column(db.INT)
