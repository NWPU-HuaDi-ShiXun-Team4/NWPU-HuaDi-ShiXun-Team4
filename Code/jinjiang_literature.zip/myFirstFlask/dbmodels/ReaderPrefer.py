from config import db


class ReaderPrefer(db.Model):
    __tablename__ = "reader_prefer_result"
    id = db.Column(db.INT, primary_key=True)
    rank = db.Column(db.INT)
    reader = db.Column(db.String(20))
    type = db.Column(db.String(20))
    rate = db.Column(db.Float(40))
