from config import db


class MonthRate(db.Model):
    __tablename__ = "month_rate"
    rank = db.Column(db.INT, primary_key=True)
    author = db.Column(db.String(20))
    name = db.Column(db.String(20))
    type = db.Column(db.String(20))
    score = db.Column(db.INT)
    word = db.Column(db.INT)
    start_time = db.Column(db.Date)
    state = db.Column(db.String(20))
