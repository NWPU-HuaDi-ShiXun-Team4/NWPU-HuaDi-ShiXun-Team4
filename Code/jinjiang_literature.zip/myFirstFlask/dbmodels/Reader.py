from config import db


class Reader(db.Model):
    __tablename__ = "reader"
    rank = db.Column(db.INT, primary_key=True)
    reader_name = db.Column(db.String(20))
    ticket_reader = db.Column(db.INT)
