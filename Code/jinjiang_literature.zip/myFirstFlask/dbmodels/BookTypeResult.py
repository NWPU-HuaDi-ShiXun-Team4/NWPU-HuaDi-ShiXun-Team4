from config import db


class BookTypeResult(db.Model):
    __tablename__ = "booktype_result"
    id = db.Column(db.INT, primary_key=True)
    type = db.Column(db.String(20))
    num = db.Column(db.INT)
    proportion = db.Column(db.Float(40))
