from flask_sqlalchemy import SQLAlchemy
from flask import Flask

app = Flask(__name__)   # flask实例

# 配置数据库
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:root@localhost:3306/jinjiang"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# 初始化数据连接
db = SQLAlchemy(app)
