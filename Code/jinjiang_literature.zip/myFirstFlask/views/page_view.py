from flask import Blueprint, render_template

# page:当前蓝图的名称
page = Blueprint("page", __name__)


@page.route("/index1", methods=['GET', 'POST'])
def index1():
    return render_template("index1.html")


@page.route("/main")
def main():
    return render_template("main.html")


@page.route("/chronic")
def chronic():
    return render_template("chronic.html")
