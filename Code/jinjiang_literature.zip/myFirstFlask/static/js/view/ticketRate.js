var myChart6 = echarts.init(document.getElementById("center4"))
//异步加载数据
$.get('/data/get_ticket_rate').done(function(data) {
	var json_data = JSON.parse(data)

	var myColor = ['#1089E7', '#F57474', '#56D0E3', '#F8B448', '#8B78F6'];
	var option6 = {
		color: ['#ADD8E6'],
		grid: {
			left: '5%',
			right: '5%',
			bottom: '5%',
			containLabel: true
		},
		tooltip: {
			trigger: 'item',
			formatter: function(params) {
				for (var i = 0; i < option6.series[0].data.length; i++) {
					return option6.series[0].data[params.dataIndex].name + '</br>' + '类型:' +
						option6.series[0].data[params.dataIndex].type + '</br>' + '积分:' +
						option6.series[0].data[params.dataIndex].value + '</br>' + '作者:' +
						option6.series[0].data[params.dataIndex].author + '</br>'

				}

			}
		},
		calculable: true,
		xAxis: [{
			type: 'category',
			data: ['No1', 'No2', 'No3', 'No4', 'No5', 'No6', 'No7', 'No8', 'No9', 'No10', 'No11', 'No12', 'No13', 'No14',
				'No15', 'No16', 'No17', 'No18', 'No19', 'No20'
			],
			axisLine: {
				lineStyle: {
					color: '#ADD8E6'
				},
			},
			axisLabel: {
				interval: 0,
				rotate: 40,
				textStyle: {
					color: '#fff'
				}
			}
		}],
		yAxis: [{
			type: 'value',
			axisLine: {
				lineStyle: {
					color: '#ADD8E6'
				},
			},
			splitLine: {
				"show": false
			},
			axisLabel: {
				textStyle: {
					color: '#fff'
				}

			}
		}],
		series: [{
			name: '所获打赏收益',
			type: 'bar',
			barWidth: 20,
			data: json_data['series'],
		}]
	};
	<!-- 使用刚指定的配置项和数据显示图表。-->
	myChart6.setOption(option6);
});
