//异步加载数据
$.get('/data/get_booktype_result').done(function(data1) {
	var Chart1 = echarts.init(document.getElementById("left1"))
	var json_data = JSON.parse(data1)


	Chart1.on('click', function(params) {
		//柱状图下边的名称（1月,2月,……,11月,12月）params.name

		//柱子的值（2.6, 5.9, ……,6.0,2.3）params.value
		//	     alert(params.seriesIndex);


		//每个月份的第几个柱子params.seriesIndex;
		switch (params.seriesIndex) {

			case 0:
				clickpie(params.name);
				break;
			default:
				break;
		}


	});

	// 填入数据
	var myOption1 = {

		tooltip: {
			trigger: 'item',
			formatter: function(params) {
				for (var i = 0; i < myOption1.series[0].data.length; i++) {
					return myOption1.series[0].data[params.dataIndex].name +
						' : ' + myOption1.series[0].data[params.dataIndex].value + '</br>' + '占比:' +
						myOption1.series[0].data[params.dataIndex].proportion * 100 + '%' + '</br>'

				}

			}
		},
		grid: {
						x: '30%', //相当于距离左边效果:padding-left
						y: '5%', //相当于距离上边效果:padding-top
						x2:'3%',
						bottom: '5%',
			containLabel: true
		},
		series: [{
			name: '题材',
			type: 'pie',
			radius: '55%',
			center: ['40%', '60%'],
			labelLine: { //图形外文字线
				normal: {
					length: 20,
					length2: 10,
					show: true
				}
			},
			/*label: {
				normal: {
					formatter: '{b|{b}}' + '\n '+ '{c|{c}}', //图形外文字上下显示
					borderWidth: 20,
					borderRadius: 4,
					padding: [0, -50], //文字和图的边距
					rich: {
						a: {
							color: '#333',
							fontSize: 16,
							lineHeight: 30
						},
						b: { //name 文字样式
							fontSize: 16,
							lineHeight: 30,
						},
						c: { //value 文字样式
							fontSize: 16,
							lineHeight: 30,
							color: '#63BF6A',
							align: "center"
						}
					}
				}
			},*/
			data: json_data['series'],
			emphasis: {
				itemStyle: {
					shadowBlur: 10,
					shadowOffsetX: 0,
					shadowColor: 'rgba(0, 0, 0, 1)'
				}
			}
		}]
	};
	//第二个参数为true的原因是防止多次请求造成数据错乱。
	//true：覆盖掉之前的配置信息。
	Chart1.setOption(myOption1, true);
});

function clickpie(dataname) {
	$.get('/data/get_booktype_top10').done(function(data) {
		var ChartPie = echarts.init(document.getElementById("left2"))
		var json_data1 = JSON.parse(data)

		var json_data2 = json_data1[dataname]
		var len = json_data2.length
		var Option_pie = {
			color: ['#081832'],
			tooltip: {
				trigger: 'item',
				//			formatter: function(params) {
				//				for (var i = 0; i < myOption1.series[0].data.length; i++) {
				//					return myOption1.series[0].data[params.dataIndex].name +
				//						' : ' + myOption1.series[0].data[params.dataIndex].value + '</br>' + '占比:'  +
				//						myOption1.series[0].data[params.dataIndex].proportion *100+'%' + '</br>'
				//
				//				}
				//
				//			}
			},
			grid: {
				x: '5%', //相当于距离左边效果:padding-left
				y: '30%', //相当于距离上边效果:padding-top
				x2: '15%',
				bottom: '10%',
//				containLabel: true
			},

			xAxis: {
				splitLine: {
					"show": false
				},
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				},
				show:false


			},
			yAxis: {
				data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
				axisLine: {
					show: false
				},
				axisTick: {
					show: false
				}


			},


			series: [{
					name: '直接访问',
					type: 'bar',
					stack: '总量',


					label: {
						show: true,
						position: 'inside',
						formatter: function(params) {

							return json_data2[9 - params.dataIndex].rank;


						}
					},
					data: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100]
				},
				{
					name: '邮件营销',
					type: 'bar',
					stack: '总量',

					label: {
						show: true,
						position: 'inside',
						formatter: function(params) {

							return json_data2[9 - params.dataIndex].name;


						}
					},
					data: [500, 500, 500, 500, 500, 500, 500, 500, 500, 500]
				},
				{
					name: 'abs',
					type: 'bar',
					stack: '总量',

					label: {
						show: true,
						position: 'inside',
						formatter: function(params) {

							return json_data2[9 - params.dataIndex].value;


						}
					},

					data: [200, 200, 200, 200, 200, 200, 200, 200, 200, 200]
				}


			]
		};
		//第二个参数为true的原因是防止多次请求造成数据错乱。
		//true：覆盖掉之前的配置信息。
		ChartPie.setOption(Option_pie, true);

	});
}
