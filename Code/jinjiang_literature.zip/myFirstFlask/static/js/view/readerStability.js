var myChart4 = echarts.init(document.getElementById("right1"))
//异步加载数据
$.get('/data/get_reader_stability').done(function(data) {
	var json_data = JSON.parse(data)
	console.info(json_data['type'])
	console.info(json_data['proportion'])
	// 填入数据
	var option4 = {

		tooltip: {
			trigger: 'axis',
			axisPointer: { // 坐标轴指示器，坐标轴触发有效
				type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
			}
		},
		legend:{
		    left:'40%',
		    top:'10%',
		    data:['爱情','奇幻','仙侠'],
		    textStyle:{//图例文字的样式
                color:'#ccc',
                }
		},

		grid: {
            x: '5%', //相当于距离左边效果:padding-left
			y: '20%', //相当于距离上边效果:padding-top
			x2: '17%',

			bottom: '5%',
			containLabel: true
		},
		xAxis: {
			type: 'category',
			data: ['月', '季', '年'],
			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}
		},
		yAxis: {
            type: 'value',
            axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}
		},
		series: [{
				name: '爱情',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['爱情']
			},
			{
				name: '奇幻',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['奇幻']
			},
			{
				name: '剧情',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['剧情']
			},
			{
				name: '仙侠',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['仙侠']
			},
			{
				name: '轻小说',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['轻小说']
			},
			{
				name: '悬疑',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['悬疑']
			},
			{
				name: '其他衍生',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['其他衍生']
			},
			{
				name: '东方衍生',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['东方衍生']
			},
			{
				name: '科幻',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['科幻']
			},
			{
				name: '游戏',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['游戏']
			},
			{
				name: '西方衍生',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['西方衍生']
			},
			{
				name: '传奇',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['传奇']
			},
			{
				name: '古典衍生',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['古典衍生']
			},
			{
				name: '童话',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['童话']
			},
			{
				name: '武侠',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['武侠']
			},
			{
				name: '惊悚',
				type: 'bar',
				stack: '总量',
				barWidth : 30,
				data: json_data['惊悚']
			}
		]
	};

	<!-- 使用刚指定的配置项和数据显示图表。-->
	myChart4.setOption(option4);
});
