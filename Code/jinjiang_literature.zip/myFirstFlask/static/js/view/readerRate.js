//异步加载数据
$.get('/data/get_reader_rate').done(function(data) {
	var ChartOne = echarts.init(document.getElementById("center5"))
	var json_data = JSON.parse(data)

	ChartOne.on('click', function(params) {
		//柱状图下边的名称（1月,2月,……,11月,12月）params.name

		//柱子的值（2.6, 5.9, ……,6.0,2.3）params.value

		//每个月份的第几个柱子params.seriesIndex;
		switch (params.seriesIndex) {

			case 0:
				clickcharts(params.dataIndex);
				break;
		    default:
				break;
		}

	});

	// 填入数据
	var option20 = {

		tooltip: {
			//			trigger: 'item',
			//			formatter: function(params) {
			//				for (var i = 0; i < option20.series[0].data.length; i++) {
			//					return option20.series[0].data[params.dataIndex].name + '</br>' + '类型:' +
			//						option20.series[0].data[params.dataIndex].type + '</br>' + '积分:' +
			//						option20.series[0].data[params.dataIndex].value + '</br>' + '作者:' +
			//						option20.series[0].data[params.dataIndex].author + '</br>'
			//
			//				}
			//
			//			}
		},
		grid: {
			x: '7%', //相当于距离左边效果:padding-left
			y: '8%', //相当于距离上边效果:padding-top
			x2: '7%',
			bottom: '5%',
			containLabel: true
		},
		xAxis: {},
		yAxis: {
			data: ["No.1", "No.2", "No.3", "No.4", "No.5", "No.6", "No.7", "No.8", "No.9", "No.10"],
			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#63B8FF",
				}
			}

		},
		series: [{
				name: '书籍',
				type: 'bar',
				barWidth : 20,
				data: json_data['series'],
				label: {
					normal: {
						show: true,
						position: 'right'
					}
				},
				itemStyle: {
					normal: {
						//这里是重点
						color: function(params) {
							//注意，如果颜色太少的话，后面颜色不会自动循环，最好多定义几个颜色
							var colorList = ['#E6E6FA', '#B0E0E6', '#C1FFC1', '#E0FFFF', '#FFFACD', '#FFDEAD', '#FF7256','#FFFFE0','#FFE4E1','#FFDEAD'];
							return colorList[params.dataIndex]
						}
					}
				}

			}]
	};


	<!-- 使用刚指定的配置项和数据显示图表。-->
	ChartOne.setOption(option20, true);



});

function clickcharts(dataIndex) {
	$.get('/data/get_reader_rate').done(function(data) {
			var ChartTwo = echarts.init(document.getElementById("center6"))
			var json_data1 = JSON.parse(data)
			var json_data2 = json_data1['series'][dataIndex]['prefer']
			var Option21 = {

				tooltip: {
					trigger: 'item',
					//			formatter: function(params) {
					//				for (var i = 0; i < myOption1.series[0].data.length; i++) {
					//					return myOption1.series[0].data[params.dataIndex].name +
					//						' : ' + myOption1.series[0].data[params.dataIndex].value + '</br>' + '占比:'  +
					//						myOption1.series[0].data[params.dataIndex].proportion *100+'%' + '</br>'
					//
					//				}
					//
					//			}
				},
				grid: {
								x: '7%', //相当于距离左边效果:padding-left
								y: '5%', //相当于距离上边效果:padding-top
								x2:'25%',
								bottom: '15%',
					containLabel: true
				},
				series: [{
					name: '题材',
					type: 'pie',
					radius: '50%',
					center: ['40%', '50%'],
					labelLine: { //图形外文字线
						normal: {
							length: 20,
							length2: 10,
							show: true
						}
					},
					data: json_data2,
					itemStyle: {
					normal: {
						//这里是重点
						color: function(params) {
							//注意，如果颜色太少的话，后面颜色不会自动循环，最好多定义几个颜色
							var colorList = ['#F0FFF0', '#B0E0E6', '#BCD2EE', '#E0FFFF', '#FFFACD', '#FFDEAD', '#FF7256','#FFFFE0','#FFE4E1','#FFDEAD'];
							return colorList[params.dataIndex]
							}
						}
					},
					emphasis: {
						itemStyle: {
							shadowBlur: 10,
							shadowOffsetX: 0,
							shadowColor: 'rgba(0, 0, 0, 1)'
						}
					}
				}]
			};
			//第二个参数为true的原因是防止多次请求造成数据错乱。
			//true：覆盖掉之前的配置信息。
			ChartTwo.setOption(Option21, true);

		});
	}
