/*  月度排行  */

var myChart1 = echarts.init(document.getElementById("center1"))
//异步加载数据
$.get('/data/get_month_rate').done(function(data2) {
	var json_data = JSON.parse(data2)

	// 填入数据
	var option1 = {

		tooltip: {
		    trigger: 'item',
			formatter: function(params) {
				for (var i = 0; i < option1.series[0].data.length; i++) {
					return option1.series[0].data[params.dataIndex].name +'</br>' + '类型:'  +
						option1.series[0].data[params.dataIndex].type + '</br>' + '积分:'  +
					    option1.series[0].data[params.dataIndex].value + '</br>' + '作者:'  +
						option1.series[0].data[params.dataIndex].author+ '</br>'

				}

			}
		},
		grid: {
			x: '5%', //相当于距离左边效果:padding-left
			y: '15%', //相当于距离上边效果:padding-top
			x2: '8%',
			bottom: '1%',
			containLabel: true
		},
		xAxis: {
			data: ["No.1", "No.2", "No.3", "No.4", "No.5", "No.6", "No.7", "No.8", "No.9", "No.10", "No.11", "No.12", "No.13",
				"No.14", "No.15", "No.16", "No.17", "No.18", "No.19", "No.20"
			],

			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}


		},
		yAxis: {
			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}

		},
		series: [{
			name: '书籍',
			type: 'bar',
			data: json_data['series'],
			itemStyle: {
				normal: {
					//这里是重点
					color: function(params) {
						//注意，如果颜色太少的话，后面颜色不会自动循环，最好多定义几个颜色
						var colorList = ['#EEDC82', '#EEDC82', '#EEDC83', '#EEDC82', '#EEDC82', '#EEDC82', '#EEDC82'];
						return colorList[params.dataIndex]
					}
				}
			}

		}]
	};

	<!-- 使用刚指定的配置项和数据显示图表。-->
	myChart1.setOption(option1);
});
// $.ajax({
//     type: "GET",
//     url: "/data/get_month_result",
//     // data: "data",
//     success: function (data) {
//         // 获取数据并保存至变量
//         json_data = JSON.parse(data)
//         console.info(json_data['type'])
//         console.info(json_data['rate'])
//         // var data_list = msg.data;
//         // var x_data = new Array();
//         // var y_data = new Array();
//         // for (var i = 0; i < data_list.length; i++) {
//         //     x_data.push(data_list[i].type);
//         //     y_data.push(data_list[i].rate)
//         // }
//         ;
//         // 显示标题，图例和空的坐标轴
//         var option2 = ({
//             title: {
//                 text: '异步数据加载示例'
//             },
//             tooltip: {},
//             legend: {
//                 data: ['销量']
//             },
//             xAxis: {
//                 data: json_data['type']
//             },
//             yAxis: {},
//             series: [{
//                 name: '销量',
//                 type: 'bar',
//                 data: json_data['rate']
//             }]
//         });
//         myChart2.setOption(option2);
//     },
//     error: function (htmlhttp) {
//         alert(htmlhttp.status)
//     }
// })
