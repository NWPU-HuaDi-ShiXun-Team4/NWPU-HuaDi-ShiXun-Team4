var myChart5 = echarts.init(document.getElementById("right2"))
//异步加载数据
$.get('/data/get_novel_rate').done(function(data) {
	var json_data = JSON.parse(data)

	// 填入数据
	var option5 = {

		tooltip: {
			trigger: 'item',
			formatter: function(params) {
				for (var i = 0; i < option5.series[0].data.length; i++) {
					return option5.series[0].data[params.dataIndex].name + '</br>' + '类型:' +
						option5.series[0].data[params.dataIndex].type + '</br>' + '积分:' +
						option5.series[0].data[params.dataIndex].value + '</br>' + '作者:' +
						option5.series[0].data[params.dataIndex].author + '</br>'

				}

			}
		},
		grid: {
			x: '7%', //相当于距离左边效果:padding-left
			y: '8%', //相当于距离上边效果:padding-top
			x2: '7%',
			bottom: '5%',
			containLabel: true
		},
		xAxis: {
//			type: 'value',
//			axisLine: { //x轴文字颜色
//				lineStyle: {
//					color: "#fff",
//				}
//			}


		},
		yAxis: {
			data: ["No.1", "No.2", "No.3", "No.4", "No.5", "No.6", "No.7", "No.8", "No.9", "No.10", "No.11", "No.12", "No.13",
				"No.14", "No.15", "No.16", "No.17", "No.18", "No.19", "No.20"
			],
			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}

		},
		series: [{
			name: '书籍',
			type: 'bar',
			data: json_data['series'],
			label: {
				normal: {
				    show: true,
				    position: 'right'
				}
			},
			itemStyle: {
				normal: {
					//这里是重点
					color: function(params) {
						//注意，如果颜色太少的话，后面颜色不会自动循环，最好多定义几个颜色
						var colorList = ['#F0FFF0', '#F0FFF0', '#F0FFF0', '#F0FFF0', '#F0FFF0', '#F0FFF0', '#F0FFF0'];
						return colorList[params.dataIndex]
					}
				}
			}

		}]
	};

	<!-- 使用刚指定的配置项和数据显示图表。-->
	myChart5.setOption(option5);
});
