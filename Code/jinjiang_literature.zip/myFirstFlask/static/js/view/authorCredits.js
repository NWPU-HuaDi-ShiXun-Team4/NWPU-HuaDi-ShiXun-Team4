var chart_author_score = echarts.init(document.getElementById('right3'));
var maskImage = new Image();
//异步加载数据
$.get('/data/get_author_credit').done(function (data) {
    var json_data = JSON.parse(data)

    // 填入数据
   option_author_score = {

        tooltip: {
            trigger: 'item',
            formatter: function (params) {
                for (var i = 0; i < option_author_score.series[0].data.length; i++) {
                    return option_author_score.series[0].data[params.dataIndex].name+
                        ' : ' + option_author_score.series[0].data[params.dataIndex].value + '</br>' + "代表作 : " +
                        option_author_score.series[0].data[params.dataIndex].book1 +'</br>'+'&emsp;'+'&emsp;'+'&emsp;'+'&emsp;'+
                        option_author_score.series[0].data[params.dataIndex].book2 +'</br>'+'&emsp;'+'&emsp;'+'&emsp;'+'&emsp;'+
                        option_author_score.series[0].data[params.dataIndex].book3 +'</br>'+'&emsp;'+'&emsp;'+'&emsp;'+'&emsp;'+
                        option_author_score.series[0].data[params.dataIndex].book4 +'</br>'+'&emsp;'+'&emsp;'+'&emsp;'+'&emsp;'+
                        option_author_score.series[0].data[params.dataIndex].book5

                }
            }
        },
        series: [{
            type: 'wordCloud',
           gridSize: 1,
			//用来调整字的大小范围
			sizeRange: [6, 40],
			//用来调整词的旋转方向，，[0,0]--代表着没有角度，也就是词为水平方向，需要设置角度参考注释内容
			rotationRange: [0, 0],
			shape: 'pentagon',
			width: 300,
			height: 300,

            maskImage: maskImage,
            drawOutOfBound: false,
            textStyle: {
                normal: {
                    color: function () {
                        return 'rgb(' + [
                            Math.round(Math.random() * 160),
                            Math.round(Math.random() * 160),
                            Math.round(Math.random() * 160)
                        ].join(',') + ')';
                    }
                },
                emphasis: {
                    shadowBlur: 10,
                    shadowColor: '#333'
                }
            },
            //位置相关设置
			left: "center",
            top: "center",
            right: null,
            bottom: null,

            data: json_data['series']


        }]
    };

     maskImage.onload = function() {
		 chart_author_score.setOption(option_author_score);

	}
	window.addEventListener("resize",function(){
            chart.resize();
        }) ;

	maskImage.src ='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAYAAAB5fY51AAAbNElEQVR4Xu2dC9h2U5nHf4UZEwo5Fg2RHHOcohxqMI6pjBBGaibHCEMOMSoMoZicaUaSmDGTSmmmuiZRTTRGkmPo4HzooByGiq5/337yfN/3vu+z9/Osvfc6/Nd1vdf3uax1r/v+3ev9f2vvvQ4vwMUETMAEEiHwgkT8tJsmYAImgAXLg8AETCAZAhasZFJlR03ABCxYHgMmYALJELBgJZMqO2oCJmDB8hgwARNIhoAFK5lU2VETMAELlseACZhAMgQsWMmkyo6agAlYsDwGTMAEkiFgwUomVXbUBEzAguUxYAImkAwBC1YyqbKjJmACFiyPARMwgWQIWLCSSZUdNQETsGB5DJiACSRDwIKVTKrsqAmYgAXLY8AETCAZAhasZFJlR03ABCxYHgMmYALJELBgJZMqO2oCJmDB8hgwARNIhoAFK5lU2VETMAELlseACZhAMgQsWMmkyo6agAlYsDwGQhFYGFhu6Oe3wJ3Aj6uf/w/Vke2US8CCVW7uQ0X+RuCdwB4zGHwQ+CRwIXBbqI5tpzwCFqzych4q4rWAY4C3NjCoWZaE61Dg8QbtXNUE/kDAguWBMA4Bzaq+ACw0TmPg5kro9MjoYgK1CViwaqNyxYrAfsAZgWhsDFwTyJbNFEDAglVAkgOGuBVwZUB7MqWX9Y8FtmlzmRKwYGWa2JbCuh9YOrDtK4DtAtu0uUwJWLAyTWwLYekxUI+DbZQTgSPaMGybeRGwYOWVz7aiWQe4vi3jld11gf9ruQ+bT5yABSvxBHbk/jnAXi33dS6wd8t92HziBCxYiSewA/fX7mjm8yywHnBDBzG5i0QJWLASTVyHbp8F7NNRf2cD+3bUl7tJkIAFK8GkdejymsD3Ouzvd4DeZd3YYZ/uKiECFqyEktWDq2f2MOPRjK6tr5E9IHSXIQlYsELSzMvWa3qa6fymepf1/bxwOpoQBCxYISjmaeN04L09haY1X/v31Le7jZiABSvi5PTo2urATT32/0z1LusHPfrgriMkYMGKMCkRuPTxCGY4muEdEAELuxARAQtWRMmIxJXVgBhmNjo7S+uydBSNiwn8gYAFywNhTgKnAe+LBMs/AQdG4ovdiICABSuCJETkwirALRH58xSglfa3R+STXemRgAWrR/gRdn1qhDMazfgOipCVXeqBgAWrB+iRdrkycGuEvj0BaMX9XRH6Zpc6JmDB6hh4xN19FDg4Uv8+Bvx9pL7ZrQ4JWLA6hB1xVytF/p5IN+ysUd1vGDFGu9Y2AQtW24TTsH8ycEjkrmoGGLuPkSNM3z0LVvo5nDSCVwF3TGqkg/a/ArRG7N4O+nIXkRKwYEWamA7dOqm62LTDLsfuSjPB94/d2g2TJ2DBSj6FEwWwApDSZaa/BLRW7MGJonbjZAlYsJJNXRDHdVvNYUEsdWdEM8LUfO6OTuY9WbAyT/AM4b0y0bVNvwD0VfPRclNXbuQWrHJzfwJweKLh+x7DRBM3qdsWrEkJptl+OeBHabr+B69/BqwI6J2WS0EELFgFJXso1OOBIxMPXTPE1GNIPAXdu2/B6p553z2+AvhJ304E6F/vsJYHtArepRACFqxCEj0U5nHABzIJWzPFozKJxWHUIGDBqgEpoyrLAj/NKJ6HAb2P07lZLgUQsGAVkOShED8MHJ1ZyJox5hZTZikKF44FKxzL2C29PNN9eA8BmjnqPkOXzAlYsDJP8FB4HwL+IdNwNXM8JtPYHNYQAQtWGcPhZcB9GYf6AKAZ5HMZx+jQfGtOMWPggwXMQDSDVJwuGRPwDCvj5FahLQVoBpJ7ub+aZeUeZ9HxWbDyT38Js6tBFvW1UF8NXTIlYMHKNLFVWEsWdnaUTiPVF0OXTAlYsDJNbBVWSbOrQSaPAHSag0uGBCxYGSa1CmlxQCvBSyv3ANov6ZIhAQtWhkkteHY1yOahwCn5prbcyCxYeeZ+MeCRPEOrFZVOo9AeQ5fMCFiwMkuoZ1d/TOhBwGl5prfcqCxY+eV+0epEzvwiaxbRj6vzspq1cu2oCViwok7PWM6V+GVwOlD7A2eMRdGNoiRgwYoyLWM7tQjw87Fb59fwbkB3L7pkQsCClUki/e5q2kTuA5yTV5rLjcaClU/uX+JbZKZM5l3VDTv5ZLrgSCxY+STf766mz+WewPn5pLrcSCxYeeT+xcBjeYTSShQ/rG6LbsW4jXZHwILVHes2e/LsajTddwMXjK7mGjETsGDFnJ16vi0I/Lpe1aJr3QG8umgCGQRvwUo/iZ5d1c/h7sBF9au7ZmwELFixZaSZPwv45uNGwG4DVmnUwpWjImDBiiodjZ3x7KoxMnYBLmnezC1iIGDBiiEL4/nwZ8CT4zUtutWtwKpFE0g4eAtWusnz7Gr83O0IXDZ+c7fsi4AFqy/yk/U7P/DUZCaKbn0zsHrRBBIN3oKVZuI8u5o8b9sDl09uxha6JGDB6pJ2mL7+BHg6jKmirdwIrFU0gQSDt2CllzTPrsLl7C3AF8KZs6W2CViw2iYc1v58wDNhTRZt7XpgvaIJJBa8BSuthHl2FT5f2wBXhjdri20QsGC1QbUdm/MAv23HdNFWrwXWL5pAQsFbsNJJlmdX7eVqC+Ar7Zm35VAELFihSLZr54XA79rtomjr3wbeUDSBRIK3YKWRKM+u2s/TpsB/t9+Ne5iEgAVrEnrdtX2uu66K7elqYJNio08kcAtWXIlaotqYu1r1pzbp6u+Lx+Vmtt7oinsdQaMN0voZ/P2RbCNOLDALVj8J0zspidFAkAZ/9ykC/eRjVK8D4RoWM+1H9H7OUeQC/38LVmCgU5hbagpx0sZbXSnvki4BidWcs7FbAP24tETAghUOrNZJzfkoJ2FaKVwXtpQAAd28Pfw4qb//APhpAr5H76IFa7wULT3H45yE6TXAQuOZc6sCCNw3x7sxiZh+JHAuNQlYsGYGpb17w++aBsK0fE2+rmYCowjozsTBo6UeJ2+qhMx7RqcgZ8F6HsrLh8RpDUA/mjXpsDwXE+iSwG/mmI0NROz2Lp2Isa8SBUvnSQ3eNQ1mTBKmZWJMkH0ygSECut178H5MXykHQqbHzSJK7oIlEZI4DQuTZk56Qe5iArkQeLASMj1S6r3YQMgkcFmVXARLj2161zQsTJo1LZlVthyMCTQjcHf1fmwgYIM/k92XmqJgvWIKYdIsysUETGA0gWer2djwI6WE7K7RTfuvEbNg6d694ZffmjHpxwsu+x839iA/Ao9Xi16HHyklZA/FFGosgqVlAgNBGvzpBZcxjRT7UioB7aOc85FS//1EH0D6ECwtutwM2GBIpLzgso/su08TGJ/At4AvAt+sfsa31KBll4KlM5105tCGDfxzVRMwgfgJXAV8CNCfrZYuBGsF4OPA1q1GYuMmYAJ9E5BoaWLSWmlbsHxSZmups2ETiJLAxcBubXnWpmDtBZzTluO2awImEC2B04ED2vCuLcHaEvhyGw7bpgmYQBIEjgOODu1pG4I1L6C73tYJ7aztmYAJJENAd2iuXW0VCuZ0G4J1IHBqMA9tyARMIFUCpwCHhnQ+tGC9tJpd6cugiwmYQNkEHq1mWfeGwhBasPxVMFRmbMcE8iDwbuCCUKGEFiw5tkco52zHBEwgeQJnAfuFiiK0YGmZvq/8DpUd2zGB9Al8F3htqDBCC5Y2Si4WyjnbMQETyIJAMJ0JZqjC+iSgY2FcTMAETEAEdIhgsI9woQVLXwN0mYOLCZiACYjA14DNQ6EILVg3VkfGhPLPdkzABNImcB6gbXpBSmjB+gawcRDPbMQETCAHAvsCZ4cKJLRgvRfQxkcXEzABE9D2HC0m/1UoFKEFa0HgBmDFUA7ajgmYQLIEPg38TUjvQwuWfDsKODakk7ZlAiaQJIFtgS+F9LwNwVoY+DqwVkhHbcsETCApAgcBp4X2uA3Bko9vBS4P7aztmYAJJEHgCmC7NjxtS7Dkq46Y0VEzLiZgAuUQ0Iv2+doKt03Bks8XAru35bztmoAJREVAW/OWaNOjtgVLvuvGnP3bDMK2TcAEeidwO7By2150IViKQV8N9fXQxQRMID8C36kuRm49sq4ES4HoqNSTWo/IHZiACXRJQJfNdHbnaJeCJYh7Aud2SdN9mYAJtEbgM8CurVmfwnDXgiUXdgJ02eI8XQbqvkzABIISOBPQVrxOSx+CpQB1b6FEa9FOo3VnJmACIQi0cudgHcf6Eiz5tkElWsvXcdR1TMAEoiBwcJ/X+PUpWKK/aiVa3sYTxVi0EyYwI4F3AZ/sk1HfgqXYdUKpHg836ROE+zYBE5iRgLbbfb5vRjEIlhjoWBqJViv7j/qG7P5NIHECmkxcHUMMsQjWgMWnQp+fEwNk+2ACCRN4DXBTLP7HJljiohNLO/9cGktC7IcJRELgKWAlINg18yHiilGwFJc+m34gRIC2YQIm0JjAw4C+3uvavqhKrIIlSN7KE9VQsTOFELgr5iPOYxYsjQ9v5Snkt8RhRkFA9zGsE4Un0zgRu2DJbW3l0Z6lF8YM0r6ZQOIE9BUw+qVFKQiWxsFW1bKHRRIfFHbfBGIkoIsidGFE9CUVwRLI11eitVz0VO2gCaRD4FLgHam4m5JgielqlWitmQpg+2kCERM4v3pPHLGLs7uWmmDJ+2Uq0do4Gcp21ATiI6DDNA+Lz62ZPUpRsBTRQpVovTk14PbXBCIgcARwYgR+NHYhVcEaBHoRsFvjqN3ABMolsBdwXqrhpy5Y4n4GsF+qCbDfJtAhgR2ByzrsL3hXOQiWoBwPHBmcjg2aQB4EngW2AL6Weji5CJby8H7gI6knxP6bQGACjwGbAtcHttuLuZwESwD1fH5OLyTdqQnER0AnLWj1+t3xuTaeR7kJlijsXH1B9Fae8caEW+VB4FbgDcAv8ghnVhQ5Cpbi8laenEapY2lK4DrgdU0bpVA/V8ESe2/lSWEE2sfQBPRiffPQRmOxl7NgifHq1eOhjnl1MYHcCVwObJ9zkLkLlnK3bCVaG+WcSMdWPAHdh/DO3CmUIFjK4Ysr0UriCI3cB53jC06gl2vjg0dRw2ApgjVA8Wlg1xpcXMUEUiGgPYHaG1hEKU2wlFT9a7RvEdl1kLkT0EUt/5h7kMPxlShYil9JLuZfpZIGdEGx7l/toy0o5HzXYdVJos4CSvKIjTrBuU7WBPYALsw6wmmCK3WGNcCxN3B2iYl3zEkSeBrYBfhskt4HcLp0wRJCnWd9ccar/gMME5uIgMAj1Qejr0bgS28uWLBmod+6Eq2Fe8uEOzaB6Qlo87K+bn+ndEgWrOdHgDaKaqb156UPCscfFYEbqw39t0XlVU/OWLBmB++tPD0NRHc7JYFvAjsAD5nPLAIWrLlHgrfy+LcjBgJfBt4KPBODM7H4YMGaOhMvqR4Pt4klUfajKAL/Wj0GFhV0nWAtWDNT0jstfUZ2MYGuCHwCeE9XnaXWjwVrdMbOAvYZXc01TGBiAqcCB09sJWMDFqx6yT0BOLxeVdcygbEIfBg4ZqyWBTWyYNVPtgRLwuViAqEJHAqcEtpojvYsWM2yqkdDPSK6mEAoAtoedm4oY7nbsWA1z7BewutlvIsJTEpAY+mSSY2U1N6C1TzbywD3NG/mFiYwFwGNpfvMpT4BC1Z9VoOaWnl8WfNmbmECcxF4G/A5c6lPwIJVn9Wg5snAIc2buYUJzEVAB0nq1FCXmgQsWDVBDVW7BtiweTO3MIG5COiomL8yl/oELFj1WQ1qam/XfM2buYUJzEXgMcBHGjUYGBasBrCApYAHmjVxbROYkcBCwONmVI+ABasep0Et7Z7X7bouJhCKwJuAq0IZy92OBatZhnVphS6vcDGBUAQ0nk4KZSx3OxasZhn+OvDGZk1c2wRmJPDvwNvNqB4BC1Y9ToNaetewQLMmrm0CMxL4CbCcGdUjYMGqx0m1FgN0c4mLCYQm4N/DmkQNqiYoYFvgivrVXdMEahNYB7ihdu2CK1qw6if/OK9Krg/LNRsR2As4r1GLQitbsOonXquSN6tf3TVNoDYBH4tcE5UFqyYo4BdelVwflms2IvB9YM1GLQqtbMGql3htn5BguZhAWwT8u1iDrCHVgARsCeieOBcTaIvAq4A72zKei10LVr1MftAXBNQD5VpjE9gZ0H2ELjMQsGDVGx7/CWxRr6prmcBYBD7qc9ZGc7NgjWakGg8Di9er6lomMBaBq4FNxmpZUCML1uhkLwj8enQ11zCBiQg8BbxoIgsFNLZgjU6y1l5pDZaLCbRNQOetPdR2Jynbt2CNzt5RwLGjq7mGCUxMYCtA70tdpiFgwRo9NLR/UPsIXUygbQJHA9oC5mLBGnsM6N64l43d2g1NoD4B/eO4Xf3q5dX0DGvmnM8P6GWoiwl0QeBBYOkuOkq1DwvWzJnT6aI6ZdTFBLoioK/ST3TVWWr9WLBmztjhwAmpJdX+Jk1gI+CbSUfQovMWrJnh/gewfYv8bdoE5iRwAHC6sUxNwII188j4kc/b9q9OxwQuAnbvuM9kurNgTZ+qeYHfJJNJO5oLgduAVXIJJnQcFqzpiW4IXBMauO2ZQA0C/r2cBpLBTD96DgFOrjG4XMUEQhNYC7gxtNEc7Fmwps/ipcBOOSTZMSRH4F3AJ5PzugOHLVjTQ74D0CmQLibQNYEzgP277jSF/ixY02fpuRQSaB+zJHAtsH6WkU0YlAVraoAaLP8zIVs3N4FxCTwLzDNu45zbWbCmzu6BwKk5J96xRU9gReCu6L3s2EEL1tTAtXhvt45z4e5MYJjADoB2WrgMEbBgTT0cbgZW9UgxgR4JHA/o8EgXC9bIMeAX7iMRuULLBP6rug+z5W7SMu8Z1tz5Wg/4blpptLcZEtBN44tmGNdEIVmw5sb3Xu+Wn2hMuXE4AktWV8yFs5i4JQvW3An8F0ArjV1MoG8CWwJ6NHSpCFiw5h4K3wPW9AgxgQgIHAGcGIEf0bhgwZo7FX7hHs3wLN6Rf/N+1tnHgAVrdh7aJX9D8b8mBhALAR0g+cpYnInBDwvW7FnYCzgnhsTYBxOoCCwAPGkaswhYsGYfCRIriZaLCcRCQAdJfisWZ/r2w4I1ewauA/6i76S4fxMYIqBlNmeaiGdYU42B33qXvH81IiPwz8DfReZTb+54hvU8+jWA7/eWCXdsAlMT0DKbtQ3HM6w5x4AWi2rRqIsJxEbAE4sqIwbx/NDU5ZV6X+AyGYGvAcdWJo4GNpvMnFtXC5k9+/dXwtl+GfQl5vX+9RibwJXAcVOc1LpBdUzK1mNbdsM9gAuNwcsahsfAU8D8HhSNCXy+mlFdP6LluoBmXG9p3IMbnAYcZAwWrMEY0E27t3hANCJwWSVUNzVqBfq4IeF6e8N2JVf/BvDGkgEMYvc7rFkkdByyjkV2GU3gM5VQ6Ur1ScrKlXDtMomRQto+ASxYSKwzhmnBmoXnY55yj/x10MWeepl+98iazSqsUL3j0nsal+kJiFNo9snxtmDNStlVwCbJZa8bh8+rXqbf03J3ywE6TmXPlvtJ1fxfA59N1flQfluwZpH8FbBQKKiZ2NF2EM2oHuo4nmWBw4D9Ou439u70BVbv/oouFqxZ19HrWnoX0NYkrUeTUOlM8T7Ly4BD/Kj+xxR8Cdi2z4TE0LcFC3YCLo0hGT36oONLJFT6V/zxHv2Yqmuda65P+pp1lVzuB15eMgDFbsGCjwDvL3Qg/BI4o5pRPRM5g8WA9xV+V1/xl1JYsOCrBW4feXhIqCLXqbncW6TaQqX3OfOl5vyE/m4BfGVCG0k3t2DBzwq6/+3e6mylHC42eDGwbzXj0qmcJZTDmfVEUGwpXbD0KV3nZudetH5HX/203iy3IrHSKbGacS2cW3BzxKN3re/IPMYZwytdsN6W+doWrUaXUOk9Ve5F+0DfU824lsg02NsB7RAotpQuWPp8f1SG2ddRJGcB52YY26iQ9F5LwqVFqMuMqpzg/38RoI36RZbSBUtrW3I69uR/K6G6oMjRPHvQL6yES8shls+IxxuAb2cUT6NQShesB4ClGhGLs7IGsGZUF8fpXu9e6Ux0LUJ9de+eTO6AdgAo10WWkgVLK6nvSzzr2gN5NqAbgl1GE9Ax2FqEqiNuUi2fqGaOqfo/kd8lC5bOF/r6RPT6a6y1OBKqz/XnQtI9714tQl0nwSj0j9SbEvQ7iMsWrCAYOzPyxepmar17c5mcwK7VItT1JzfVmQULVmeo4+oopRmWjhXRrdRale8SnsDO1SLUjcKbDm7RghUcaRoGUxAsLRSUUOmIXJf2CewA7A1s2n5XY/dgwRobXdoNdYLjnZGG8KlqDVWxn697zosWFGst11Y9+zFV97o7828j9KsTl0p+hyXAOrJj6U5I1+tEX4C02FPrqVz6J7BdJVwxnUOlM/Av6R9NPx6ULlh6N6R/TfssOtZlIFS+LLPPTEzf9zaVcPV9RZkOWNRynEfixNS+V6UL1geBY9rHPGUPOihPQqUz02/tyQd324zAlpVwbd+sWbDaVwCa9RVbSheslwLXAnqf1VX5+ZBQ3dVVp+4nKIHNK+Hq+m5Fn4cVNI1pGjsQOLUD1x+shOp84Kcd9Ocu2ifwl5VwaVlE20X3ZmrBa9Gl9BmWkj9vNctqa9WzxEmPfhIqiZZLfgR0RZy+KmohalvldcB1bRlPxa4Fa1amtJtf/4JpJ3yooiUTA6HSY6BL/gQ2rIQr9ExoR+Cy/PGNjtCC9TyjRQHdbvzm0dhmrHFLJVQSq19PaMvN0ySwQSVc2mw9abFYDRG0YM0+nPR4qAP9NL3X5+Mm5XtDQvV0k4aumy2B11ZjScfbNC06LfZI4PKmDXOub8GaOrtaTKpzwkcJl9bDaKp+dXXEy3M5DxbHNjaBdauZu5ZF6F3UTEVHHukUjhMyOP5obGDTNbRgzYz0T6tjdnV9uo7b1c+j1ZaeH3pABR+PJRhcCZCADX4GMeuFun50dJBfJUwzEixYJfyKOEYTyISABSuTRDoMEyiBgAWrhCw7RhPIhIAFK5NEOgwTKIGABauELDtGE8iEgAUrk0Q6DBMogYAFq4QsO0YTyISABSuTRDoMEyiBgAWrhCw7RhPIhIAFK5NEOgwTKIGABauELDtGE8iEgAUrk0Q6DBMogYAFq4QsO0YTyISABSuTRDoMEyiBgAWrhCw7RhPIhIAFK5NEOgwTKIGABauELDtGE8iEgAUrk0Q6DBMogYAFq4QsO0YTyISABSuTRDoMEyiBgAWrhCw7RhPIhIAFK5NEOgwTKIGABauELDtGE8iEgAUrk0Q6DBMogYAFq4QsO0YTyITA7wGaOdVLmwjm4gAAAABJRU5ErkJggg==';


});

