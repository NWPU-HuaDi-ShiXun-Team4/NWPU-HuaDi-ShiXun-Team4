/*  季度排行  */

var myChart2 = echarts.init(document.getElementById("center2"))
$.get('/data/get_quarter_rate').done(function(data3) {
	var json_data = JSON.parse(data3)

	// 填入数据
	var option2 = {

		tooltip: {
		    trigger: 'item',
			formatter: function(params) {
				for (var i = 0; i < option2.series[0].data.length; i++) {
					return option2.series[0].data[params.dataIndex].name + '</br>' + '类型:'  +
						option2.series[0].data[params.dataIndex].type + '</br>' + '积分:'  +
					    option2.series[0].data[params.dataIndex].value + '</br>' + '作者:'  +
						option2.series[0].data[params.dataIndex].author+ '</br>'

				}

			}
		},
		grid: {
			x: '5%', //相当于距离左边效果:padding-left
			y: '15%', //相当于距离上边效果:padding-top
			x2: '8%',
			bottom: '1%',
			containLabel: true
		},
		xAxis: {
			data: ["No.1", "No.2", "No.3", "No.4", "No.5", "No.6", "No.7", "No.8", "No.9", "No.10", "No.11", "No.12", "No.13",
				"No.14", "No.15", "No.16", "No.17", "No.18", "No.19", "No.20"
			],

			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}


		},
		yAxis: {
			axisLine: { //y轴文字颜色
				lineStyle: {
					color: "#fff",
				}
			}

		},
		series: [{
			name: '书籍',
			type: 'bar',
			data: json_data['series'],
			itemStyle: {
				normal: {
					//这里是重点
					color: function(params) {
						//注意，如果颜色太少的话，后面颜色不会自动循环，最好多定义几个颜色
						var colorList = ['#EED5D2', '#EED5D2', '#EED5D2','#EED5D2'];
						return colorList[params.dataIndex]
					}
				}
			}

		}]
	};

	<!-- 使用刚指定的配置项和数据显示图表。-->
	myChart2.setOption(option2);
});
